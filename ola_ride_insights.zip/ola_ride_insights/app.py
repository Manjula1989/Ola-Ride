"""Ola Ride Insights - Streamlit app.

Run:  streamlit run app.py
Pages: Overview | SQL Insights | Data Explorer | Dashboard
"""
import sqlite3
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from sql_utils import DB_PATH, load_queries, run_query  # noqa: E402

st.set_page_config(page_title="Ola Ride Insights", page_icon=":car:", layout="wide")


@st.cache_data(show_spinner=False)
def load_rides() -> pd.DataFrame:
    with sqlite3.connect(DB_PATH) as con:
        df = pd.read_sql_query("SELECT * FROM rides", con, parse_dates=["Date"])
    return df


@st.cache_data(show_spinner=False)
def cached_query(sql: str) -> pd.DataFrame:
    return run_query(sql)


if not DB_PATH.exists():
    st.error("Database not found. Run `python src/clean_data.py <path to OLA_DataSet.xlsx>` first.")
    st.stop()

rides = load_rides()
queries = load_queries()

# ---------------------------------------------------------------- sidebar
st.sidebar.title("Ola Ride Insights")
page = st.sidebar.radio("Page", ["Overview", "SQL Insights", "Data Explorer", "Dashboard"])
st.sidebar.markdown("---")
st.sidebar.caption("Filters below apply to Overview and Data Explorer.")
vehicles = st.sidebar.multiselect("Vehicle type", sorted(rides.Vehicle_Type.unique()))
statuses = st.sidebar.multiselect("Booking status", sorted(rides.Booking_Status.unique()))
dmin, dmax = rides.Date.min().date(), rides.Date.max().date()
date_range = st.sidebar.date_input("Date range", (dmin, dmax), min_value=dmin, max_value=dmax)

view = rides
if vehicles:
    view = view[view.Vehicle_Type.isin(vehicles)]
if statuses:
    view = view[view.Booking_Status.isin(statuses)]
if isinstance(date_range, tuple) and len(date_range) == 2:
    view = view[(view.Date >= pd.Timestamp(date_range[0])) & (view.Date <= pd.Timestamp(date_range[1]))]

# ---------------------------------------------------------------- pages
if page == "Overview":
    st.title("Overview")
    if view.empty:
        st.warning("No rides match the current filters.")
        st.stop()
    ok = view[view.Booking_Status == "Success"]
    c = st.columns(5)
    c[0].metric("Bookings", f"{len(view):,}")
    c[1].metric("Success rate", f"{100 * len(ok) / len(view):.1f}%")
    c[2].metric("Booking value (successful)", f"₹{ok.Booking_Value.sum():,.0f}")
    c[3].metric("Avg distance", f"{ok.Ride_Distance.mean():.1f} km" if len(ok) else "-")
    c[4].metric("Cancelled", f"{100 * view.Booking_Status.str.startswith('Canceled').mean():.1f}%")

    left, right = st.columns(2)
    with left:
        st.subheader("Ride volume over time")
        daily = view.groupby("Date").size().rename("Bookings").to_frame()
        daily["Successful"] = ok.groupby("Date").size()
        st.line_chart(daily.fillna(0))
    with right:
        st.subheader("Booking status")
        st.bar_chart(view.Booking_Status.value_counts())

    left, right = st.columns(2)
    with left:
        st.subheader("Bookings by hour of day")
        st.bar_chart(view.groupby("Hour").size())
    with right:
        st.subheader("Revenue by payment method")
        st.bar_chart(ok.groupby("Payment_Method").Booking_Value.sum())

    left, right = st.columns(2)
    with left:
        st.subheader("Cancellation reasons: customers")
        st.bar_chart(view.Cancel_Reason_Customer.value_counts())
    with right:
        st.subheader("Cancellation reasons: drivers")
        st.bar_chart(view.Cancel_Reason_Driver.value_counts())

elif page == "SQL Insights":
    st.title("SQL Insights")
    st.caption("Each query runs live against data/ola.db (SQLite). Edit the SQL to experiment.")
    required = {k: v for k, v in queries.items() if k.startswith("Q")}
    extra = {k: v for k, v in queries.items() if k.startswith("X")}
    group = st.radio("Query set", ["Required questions (Q1-Q10)", "Extra business queries"], horizontal=True)
    pool = required if group.startswith("Required") else extra
    key = st.selectbox("Question", list(pool), format_func=lambda k: f"{k}: {pool[k]['title']}")
    sql = st.text_area("SQL", pool[key]["sql"], height=220, key=f"sql_{key}")
    try:
        res = cached_query(sql)
        st.write(f"{len(res):,} row(s)")
        st.dataframe(res.head(1000))
        if len(res) > 1000:
            st.caption("Showing the first 1,000 rows. Download for the full result.")
        st.download_button("Download CSV", res.to_csv(index=False).encode(), f"{key}.csv", "text/csv")
        if res.shape[1] == 2 and pd.api.types.is_numeric_dtype(res.iloc[:, 1]) and len(res) <= 30:
            st.bar_chart(res.set_index(res.columns[0]))
    except Exception as exc:  # show SQL errors instead of crashing the app
        st.error(f"Query failed: {exc}")

elif page == "Data Explorer":
    st.title("Data Explorer")
    search = st.text_input("Search by Booking ID or Customer ID")
    cols = st.columns(3)
    pay = cols[0].multiselect("Payment method", sorted(rides.Payment_Method.dropna().unique()))
    pickup = cols[1].multiselect("Pickup location", sorted(rides.Pickup_Location.unique()))
    rating = cols[2].slider("Customer rating", 3.0, 5.0, (3.0, 5.0), 0.1)
    out = view
    if search:
        s = search.strip().lower()
        out = out[out.Booking_ID.str.lower().str.contains(s, regex=False) | out.Customer_ID.str.lower().str.contains(s, regex=False)]
    if pay:
        out = out[out.Payment_Method.isin(pay)]
    if pickup:
        out = out[out.Pickup_Location.isin(pickup)]
    if rating != (3.0, 5.0):
        out = out[out.Customer_Rating.between(*rating)]
    st.write(f"{len(out):,} of {len(rides):,} rides")
    st.dataframe(out.head(2000))
    st.download_button("Download filtered rows (CSV)", out.to_csv(index=False).encode(), "ola_filtered.csv", "text/csv")

else:
    st.title("Dashboard")
    source = st.radio("Source", ["Built-in dashboard", "Power BI report (publish-to-web URL)"], horizontal=True)
    if source.startswith("Built-in"):
        html = (ROOT / "dashboard" / "ola_dashboard.html").read_text(encoding="utf-8")
        components.html(html, height=1500, scrolling=True)
    else:
        url = st.text_input("Power BI embed URL", placeholder="https://app.powerbi.com/view?r=...")
        if url.startswith("https://app.powerbi.com/"):
            components.iframe(url, height=700, scrolling=True)
        elif url:
            st.error("Enter the 'Publish to web' link from Power BI (it starts with https://app.powerbi.com/).")
        else:
            st.info("Publish your report from Power BI (File > Embed report > Publish to web) and paste the link here.")
