# Ola Ride Insights

Analysis of 103,024 Ola ride bookings (Bengaluru, July 2024): data cleaning, SQL, an interactive dashboard,
and a Streamlit app.

## Project layout
```
app.py                     Streamlit app (Overview, SQL Insights, Data Explorer, Dashboard)
src/clean_data.py          Cleaning + feature engineering -> data/ola_clean.csv and data/ola.db
src/sql_utils.py           Loads queries from sql/queries.sql, runs them read-only
src/validate_sql.py        Runs all queries and cross-checks Q1-Q10 against pandas
src/build_dashboard.py     Builds dashboard/ola_dashboard.html (template: src/dashboard_template.html)
sql/queries.sql            The 10 required queries (Q1-Q10) plus 6 extra business queries (X1-X6)
dashboard/ola_dashboard.html   Interactive dashboard (5 views, vehicle and date slicers); opens offline
docs/power_bi_guide.md     Step-by-step Power BI build with DAX measures
```

## Run it
```bash
pip install -r requirements.txt
python src/clean_data.py path/to/OLA_DataSet.xlsx   # creates data/ola_clean.csv and data/ola.db
cd src && python validate_sql.py && cd ..            # optional: all checks should say PASS
python src/build_dashboard.py                        # optional: rebuild the dashboard
streamlit run app.py
```

## Data cleaning
- The workbook has three sheets. `July` holds the rides; `Sheet1` is a scratch sheet of formulas and `Sheet2` maps vehicle types to icon URLs (kept as table `vehicle_images`).
- Literal `"null"` text became real missing values; text was trimmed; `Date` and `Time` were combined into `Booking_Timestamp`.
- The formula-driven `Vehicle Images` column and empty helper columns were dropped. No duplicate `Booking_ID`s were found.
- `Canceled_Rides_by_Customer` / `_by_Driver` hold reasons, so they were renamed `Cancel_Reason_Customer` / `Cancel_Reason_Driver`.
- Derived features: `Hour`, `Day_Name`, `Day_Of_Week`, `Is_Weekend`, `Week_Of_Month`, `Time_Of_Day`, `Is_Success`, `Is_Incomplete`,
  `Same_Pickup_Drop`, `Fare_Per_Km`, `Realised_Revenue`.
- Missing values are expected, not errors: ratings, payment method and turnaround times exist only for successful bookings (39,057 rows have none).

**Definitions used**
- *Revenue / total booking value* = `Booking_Value` of rides with status `Success` (matches Q9). Cancelled and driver-not-found bookings carry a quoted fare but no ride, so they are excluded.
- *Incomplete rides* are bookings with status `Success` and `Incomplete_Rides = 'Yes'` (3,926). `Realised_Revenue` excludes them if you want a stricter revenue figure (₹32.83M instead of ₹35.08M).
- Average distance uses successful rides only, because other statuses record 0 km.

## SQL answers (all verified against pandas)
| Q | Question | Answer |
|---|---|---|
| 1 | Successful bookings | 63,967 rows |
| 2 | Avg distance by vehicle | eBike 25.15, Prime Plus 25.03, Prime Sedan 25.01, Mini 24.98, Bike 24.93, Prime SUV 24.88, Auto 10.04 km |
| 3 | Cancelled by customers | 10,499 |
| 4 | Top 5 customers by rides | CID954071 (5 rides), then four customers with 4 rides each (ties broken by ID) |
| 5 | Driver cancels: personal and car issue | 6,542 |
| 6 | Prime Sedan driver ratings | max 5.0, min 3.0 |
| 7 | UPI rides | 25,881 rows |
| 8 | Avg customer rating by vehicle | 3.99 to 4.01 for all vehicles |
| 9 | Total booking value, successful | ₹35,080,467 |
| 10 | Incomplete rides with reason | 3,926 rows (Customer Demand 1,601; Vehicle Breakdown 1,591; Other Issue 734) |

## Key insights
1. **Only 62.1% of bookings complete.** Drivers cancel 17.9%, customers 10.2%, and 9.8% never find a driver. Driver cancellations are the biggest leak.
2. **Driver cancellations are mostly operational.** "Personal & car related issue" (35.5%) and "Customer related issue" (29.4%) lead. Customers mainly cancel because the driver is not moving towards pickup (30.2%) or asks them to cancel (25.4%), which points to driver allocation and dispatch quality.
3. **Demand is flat, so there is no peak to optimise around.** Bookings per hour of day stay between 4,176 and 4,408, and the average per day is 3,253 to 3,385 for every weekday. (Raw weekday totals look uneven only because July 2024 has five Mondays, Tuesdays and Wednesdays and four of the rest.) Driver allocation should therefore focus on reducing cancellations and unfound drivers, not on timing.
4. **Autos are a different product.** Average Auto ride is 10.0 km against about 25 km for every other vehicle, so Auto ranks last in total distance even with similar booking counts.
5. **Cash and UPI carry 95% of revenue** (54.9% and 40.4%); cards are under 5%.
6. **Success rates barely differ by vehicle type** (61.4% to 63.0%), so vehicle type does not explain cancellations.

## Caveats
- The data is close to uniform (flat hourly demand, ratings evenly spread 3.0 to 5.0, driver and customer ratings uncorrelated at -0.003, near-identical vehicle metrics). That suggests a synthetic or generated dataset, so treat business conclusions as exercise findings.
- Fare does not scale with distance (correlation 0.002; `Fare_Per_Km` ranges from 2 to 2,981), so surge or pricing-pattern conclusions are not reliable. Query X4 shows fare per km by time of day, which differs by under 5%.
- 2,121 bookings have the same pickup and drop location (1,306 of them successful); query X5 lists suspicious rides for anomaly review.
- Only July 2024 is covered, so there is no month-over-month trend.

## Submission checklist (from the brief)
- [x] Cleaned dataset, SQL queries, validated results
- [x] Dashboard with the five views from the brief (built-in HTML version; Power BI steps in `docs/power_bi_guide.md`)
- [x] Streamlit app with SQL results, filters, search and embedded dashboard
- [ ] Build the `.pbix` in Power BI Desktop and publish the link
- [ ] Push to GitHub with meaningful commits
- [ ] Deploy the Streamlit app (e.g. Streamlit Community Cloud; commit `data/ola.db` or run `clean_data.py` at startup)
- [ ] Record the presentation of findings
