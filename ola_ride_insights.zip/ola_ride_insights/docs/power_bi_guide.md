# Power BI build guide

The brief asks for a Power BI dashboard. A `.pbix` file can only be made in Power BI Desktop, so this guide
lets you build it in about an hour from the cleaned data. `dashboard/ola_dashboard.html` is a working
reference for the layout and numbers: your report should show the same figures.

## 1. Load data
1. Power BI Desktop > Get data > Text/CSV > `data/ola_clean.csv` > Transform data.
2. Check types: `Date` = Date, `Booking_Timestamp` = Date/Time, `Hour` = Whole number, ratings and `Fare_Per_Km` = Decimal,
   `Booking_Value`, `Ride_Distance` = Whole number. Close & Apply.
   (To use MySQL instead, load `ola_clean.csv` into a `rides` table and use Get data > MySQL database.)
3. Optional: add `vehicle_images` (Vehicle_Type, Image_URL) and relate it to `rides[Vehicle_Type]` (many-to-one).

## 2. Measures (Modeling > New measure)
```DAX
Total Bookings   = COUNTROWS(rides)
Successful Rides = CALCULATE([Total Bookings], rides[Booking_Status] = "Success")
Success Rate     = DIVIDE([Successful Rides], [Total Bookings])
Revenue          = CALCULATE(SUM(rides[Booking_Value]), rides[Booking_Status] = "Success")
Total Distance   = CALCULATE(SUM(rides[Ride_Distance]), rides[Booking_Status] = "Success")
Avg Distance     = DIVIDE([Total Distance], [Successful Rides])
Customer Cancels = CALCULATE([Total Bookings], rides[Booking_Status] = "Canceled by Customer")
Driver Cancels   = CALCULATE([Total Bookings], rides[Booking_Status] = "Canceled by Driver")
Cancel Rate      = DIVIDE([Customer Cancels] + [Driver Cancels], [Total Bookings])
Avg Driver Rating   = CALCULATE(AVERAGE(rides[Driver_Ratings]), rides[Booking_Status] = "Success")
Avg Customer Rating = CALCULATE(AVERAGE(rides[Customer_Rating]), rides[Booking_Status] = "Success")
```
Expected check values (all of July): Total Bookings 103,024; Successful Rides 63,967; Revenue 35,080,467;
Success Rate 62.1%; Avg Distance 22.9 km.

## 3. Pages and visuals
Every page gets slicers for `Vehicle_Type` and `Date` (between), plus the KPI cards Total Bookings, Success Rate, Revenue.

| Page | Visual | Fields |
|---|---|---|
| Overall | Ride volume over time (line) | Axis `Date`; Values `Total Bookings`, `Successful Rides` |
| Overall | Booking status breakdown (donut or bar) | Legend `Booking_Status`; Values `Total Bookings` |
| Vehicle Type | Top 5 vehicle types by ride distance (bar) | Axis `Vehicle_Type`; Values `Total Distance`; Filters pane > Top N = 5 by `Total Distance` |
| Vehicle Type | Average customer rating by vehicle type (bar) | Axis `Vehicle_Type`; Values `Avg Customer Rating` |
| Revenue | Revenue by payment method (bar) | Axis `Payment_Method`; Values `Revenue` (filter out blank) |
| Revenue | Top 5 customers by total booking value (table) | `Customer_ID`, `Revenue`; Top N = 5 |
| Revenue | Ride distance distribution per day (column) | Axis `Date`; Values `Total Distance` |
| Cancellation | Customer cancel reasons (bar) | Axis `Cancel_Reason_Customer` (filter out blank); Values `Total Bookings` |
| Cancellation | Driver cancel reasons (bar) | Axis `Cancel_Reason_Driver` (filter out blank); Values `Total Bookings` |
| Ratings | Driver ratings distribution (column) | Axis `Driver_Ratings`; Values `Count of Booking_ID` |
| Ratings | Customer ratings distribution (column) | Axis `Customer_Rating`; Values `Count of Booking_ID` |
| Ratings | Customer vs driver ratings (scatter) | X `Avg Driver Rating`, Y `Avg Customer Rating`, Details `Vehicle_Type`, or a matrix of rating bands |

## 4. Publish and embed in Streamlit
1. Home > Publish > choose a workspace.
2. In the Power BI service: File > Embed report > Publish to web (public). Copy the link.
3. In the Streamlit app, open the Dashboard page, choose "Power BI report", and paste the link.

Publish to web makes the report public. Use it only because this dataset is a training dataset.
