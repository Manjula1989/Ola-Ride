-- =====================================================================
-- OLA Ride Insights - SQL queries
-- Table: rides (cleaned data, one row per booking), vehicle_images
-- Written for SQLite; works unchanged on MySQL/PostgreSQL except where
-- noted. Each query starts with a "-- Q<n>:" marker (used by the runner).
-- =====================================================================

-- Q1: Retrieve all successful bookings
SELECT *
FROM rides
WHERE Booking_Status = 'Success';

-- Q2: Average ride distance for each vehicle type (completed rides only; cancelled rides have distance 0)
SELECT Vehicle_Type,
       ROUND(AVG(Ride_Distance), 2) AS Avg_Ride_Distance_Km
FROM rides
WHERE Booking_Status = 'Success'
GROUP BY Vehicle_Type
ORDER BY Avg_Ride_Distance_Km DESC;

-- Q3: Total number of rides cancelled by customers
SELECT COUNT(*) AS Cancelled_By_Customer
FROM rides
WHERE Booking_Status = 'Canceled by Customer';

-- Q4: Top 5 customers who booked the highest number of rides
SELECT Customer_ID,
       COUNT(*) AS Total_Rides
FROM rides
GROUP BY Customer_ID
ORDER BY Total_Rides DESC, Customer_ID
LIMIT 5;

-- Q5: Rides cancelled by drivers due to personal and car-related issues
SELECT COUNT(*) AS Driver_Cancels_Personal_Car_Issue
FROM rides
WHERE Booking_Status = 'Canceled by Driver'
  AND Cancel_Reason_Driver = 'Personal & Car related issue';

-- Q6: Maximum and minimum driver ratings for Prime Sedan bookings
SELECT MAX(Driver_Ratings) AS Max_Driver_Rating,
       MIN(Driver_Ratings) AS Min_Driver_Rating
FROM rides
WHERE Vehicle_Type = 'Prime Sedan'
  AND Driver_Ratings IS NOT NULL;

-- Q7: All rides where payment was made using UPI
SELECT *
FROM rides
WHERE Payment_Method = 'UPI';

-- Q8: Average customer rating per vehicle type
SELECT Vehicle_Type,
       ROUND(AVG(Customer_Rating), 2) AS Avg_Customer_Rating
FROM rides
WHERE Customer_Rating IS NOT NULL
GROUP BY Vehicle_Type
ORDER BY Avg_Customer_Rating DESC;

-- Q9: Total booking value of rides completed successfully
SELECT SUM(Booking_Value) AS Total_Booking_Value
FROM rides
WHERE Booking_Status = 'Success';

-- Q10: All incomplete rides along with the reason
SELECT Booking_ID, Date, Vehicle_Type, Pickup_Location, Drop_Location,
       Booking_Value, Incomplete_Rides_Reason
FROM rides
WHERE Incomplete_Rides = 'Yes'
ORDER BY Date, Booking_ID;

-- =====================================================================
-- Extra business queries (peak demand, cancellations, pricing, fraud)
-- =====================================================================

-- X1: Peak demand hours (bookings and success rate by hour of day)
SELECT Hour,
       COUNT(*) AS Bookings,
       ROUND(100.0 * SUM(Is_Success) / COUNT(*), 1) AS Success_Rate_Pct
FROM rides
GROUP BY Hour
ORDER BY Bookings DESC;

-- X2: Cancellation and failure rate by vehicle type, with icon (JOIN)
SELECT r.Vehicle_Type,
       v.Image_URL,
       COUNT(*) AS Bookings,
       ROUND(100.0 * SUM(CASE WHEN r.Booking_Status = 'Canceled by Driver'   THEN 1 ELSE 0 END) / COUNT(*), 1) AS Driver_Cancel_Pct,
       ROUND(100.0 * SUM(CASE WHEN r.Booking_Status = 'Canceled by Customer' THEN 1 ELSE 0 END) / COUNT(*), 1) AS Customer_Cancel_Pct,
       ROUND(100.0 * SUM(CASE WHEN r.Booking_Status = 'Driver Not Found'     THEN 1 ELSE 0 END) / COUNT(*), 1) AS Driver_Not_Found_Pct
FROM rides r
LEFT JOIN vehicle_images v ON v.Vehicle_Type = r.Vehicle_Type
GROUP BY r.Vehicle_Type, v.Image_URL
ORDER BY Bookings DESC;

-- X3: Revenue by payment method (completed, non-incomplete rides)
SELECT Payment_Method,
       COUNT(*) AS Rides,
       SUM(Booking_Value) AS Revenue,
       ROUND(AVG(Booking_Value), 2) AS Avg_Fare
FROM rides
WHERE Booking_Status = 'Success' AND Incomplete_Rides = 'No'
GROUP BY Payment_Method
ORDER BY Revenue DESC;

-- X4: Pricing pattern - fare per km by time of day (surge-style effects)
SELECT Time_Of_Day,
       COUNT(*) AS Rides,
       ROUND(AVG(Fare_Per_Km), 2) AS Avg_Fare_Per_Km,
       ROUND(AVG(Booking_Value), 2) AS Avg_Fare
FROM rides
WHERE Booking_Status = 'Success'
GROUP BY Time_Of_Day
ORDER BY Avg_Fare_Per_Km DESC;

-- X5: Possible anomalies - successful rides whose pickup equals drop, or fare/km outliers
SELECT Booking_ID, Customer_ID, Vehicle_Type, Pickup_Location, Drop_Location,
       Ride_Distance, Booking_Value, Fare_Per_Km
FROM rides
WHERE Booking_Status = 'Success'
  AND (Same_Pickup_Drop = 1 OR Fare_Per_Km > 500)
ORDER BY Fare_Per_Km DESC
LIMIT 50;

-- X6: Customers with the highest repeat cancellation behaviour
SELECT Customer_ID,
       COUNT(*) AS Bookings,
       SUM(CASE WHEN Booking_Status = 'Canceled by Customer' THEN 1 ELSE 0 END) AS Customer_Cancels
FROM rides
GROUP BY Customer_ID
HAVING Customer_Cancels >= 2
ORDER BY Customer_Cancels DESC, Bookings DESC
LIMIT 20;
