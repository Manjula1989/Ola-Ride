"""Run every query in sql/queries.sql and cross-check Q1-Q10 against pandas."""
from pathlib import Path

import pandas as pd

from sql_utils import ROOT, load_queries, run_query

df = pd.read_csv(ROOT / "data" / "ola_clean.csv")
queries = load_queries()
results = {k: run_query(v["sql"]) for k, v in queries.items()}

succ = df[df.Booking_Status == "Success"]
checks = {
    "Q1 rows":  (len(results["Q1"]), len(succ)),
    "Q2 avg distance": (results["Q2"].set_index("Vehicle_Type")["Avg_Ride_Distance_Km"].round(2).to_dict(),
                        succ.groupby("Vehicle_Type").Ride_Distance.mean().round(2).to_dict()),
    "Q3 customer cancels": (int(results["Q3"].iloc[0, 0]), int((df.Booking_Status == "Canceled by Customer").sum())),
    "Q4 top5": (results["Q4"].Total_Rides.tolist(), df.Customer_ID.value_counts().head(5).tolist()),
    "Q5 driver personal/car": (int(results["Q5"].iloc[0, 0]), int((df.Cancel_Reason_Driver == "Personal & Car related issue").sum())),
    "Q6 sedan min/max": (results["Q6"].iloc[0].tolist(),
                         [df[df.Vehicle_Type == "Prime Sedan"].Driver_Ratings.max(),
                          df[df.Vehicle_Type == "Prime Sedan"].Driver_Ratings.min()]),
    "Q7 UPI rows": (len(results["Q7"]), int((df.Payment_Method == "UPI").sum())),
    "Q8 cust rating": (results["Q8"].set_index("Vehicle_Type")["Avg_Customer_Rating"].round(2).to_dict(),
                       df.groupby("Vehicle_Type").Customer_Rating.mean().round(2).to_dict()),
    "Q9 total value": (int(results["Q9"].iloc[0, 0]), int(succ.Booking_Value.sum())),
    "Q10 incomplete rows": (len(results["Q10"]), int((df.Incomplete_Rides == "Yes").sum())),
}

ok = True
for name, (sql_val, pd_val) in checks.items():
    match = sql_val == pd_val
    ok &= match
    print(f"{'PASS' if match else 'FAIL'}  {name}: sql={str(sql_val)[:90]}")
    if not match:
        print(f"      pandas={str(pd_val)[:90]}")

print("\nAll queries executed:", ", ".join(f"{k}({len(v)} rows)" for k, v in results.items()))
raise SystemExit(0 if ok else 1)
