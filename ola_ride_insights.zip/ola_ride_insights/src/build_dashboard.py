"""Build dashboard/ola_dashboard.html - a self-contained, slicer-driven stand-in for the Power BI report.

The page embeds a small pre-aggregated data cube (a few thousand rows), so it needs no server.
Usage: python src/build_dashboard.py
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
df = pd.read_csv(ROOT / "data" / "ola_clean.csv", parse_dates=["Date"])

NA = "n/a"
for c in ["Payment_Method", "Cancel_Reason_Customer", "Cancel_Reason_Driver", "Incomplete_Rides_Reason"]:
    df[c] = df[c].fillna(NA)
df["DateStr"] = df["Date"].dt.strftime("%Y-%m-%d")
df["DR"] = df["Driver_Ratings"].fillna(0)
df["CR"] = df["Customer_Rating"].fillna(0)

keys = ["DateStr", "Vehicle_Type", "Booking_Status", "Payment_Method", "Cancel_Reason_Customer",
        "Cancel_Reason_Driver", "Incomplete_Rides_Reason", "Is_Incomplete"]
cube = (df.groupby(keys, as_index=False)
          .agg(n=("Booking_ID", "size"), val=("Booking_Value", "sum"), dist=("Ride_Distance", "sum"),
               dr=("DR", "sum"), cr=("CR", "sum")))

lookups = {k: sorted(df[k].unique().tolist()) for k in keys[:-1]}
idx = {k: {v: i for i, v in enumerate(vals)} for k, vals in lookups.items()}
rows = []
for r in cube.itertuples(index=False):
    rows.append([idx["DateStr"][r.DateStr], idx["Vehicle_Type"][r.Vehicle_Type], idx["Booking_Status"][r.Booking_Status],
                 idx["Payment_Method"][r.Payment_Method], idx["Cancel_Reason_Customer"][r.Cancel_Reason_Customer],
                 idx["Cancel_Reason_Driver"][r.Cancel_Reason_Driver], idx["Incomplete_Rides_Reason"][r.Incomplete_Rides_Reason],
                 int(r.Is_Incomplete), int(r.n), int(r.val), int(r.dist), round(float(r.dr), 1), round(float(r.cr), 1)])

# Rating histograms (0.1 steps, 3.0-5.0) and 5x5 heat-map (0.5 steps), per vehicle type.
s = df[df.Booking_Status == "Success"].copy()
vehicles = lookups["Vehicle_Type"]
hist = {}
for v in vehicles:
    sv = s[s.Vehicle_Type == v]
    d = np.bincount(((sv.Driver_Ratings - 3) * 10).round().astype(int), minlength=21).tolist()
    c = np.bincount(((sv.Customer_Rating - 3) * 10).round().astype(int), minlength=21).tolist()
    hd = ((sv.Driver_Ratings * 2).round() / 2 - 3).mul(2).astype(int).clip(0, 4)
    hc = ((sv.Customer_Rating * 2).round() / 2 - 3).mul(2).astype(int).clip(0, 4)
    heat = np.zeros((5, 5), dtype=int)
    for a, b in zip(hd, hc):
        heat[a, b] += 1
    hist[v] = {"dr": d, "cr": c, "heat": heat.tolist()}

top_cust = (s.groupby("Customer_ID").agg(value=("Booking_Value", "sum"), rides=("Booking_ID", "size"))
              .sort_values("value", ascending=False).head(5).reset_index().to_dict("records"))

payload = {"lookups": lookups, "rows": rows, "hist": hist, "topCustomers": top_cust}
template = (ROOT / "src" / "dashboard_template.html").read_text()
out = ROOT / "dashboard" / "ola_dashboard.html"
out.parent.mkdir(exist_ok=True)
out.write_text(template.replace("/*__DATA__*/null", json.dumps(payload, separators=(",", ":"))))
print(f"cube rows: {len(rows):,}  ->  {out}  ({out.stat().st_size/1024:.0f} KB)")
