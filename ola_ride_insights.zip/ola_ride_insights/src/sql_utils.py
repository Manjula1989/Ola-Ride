"""Helpers for loading and running the named queries in sql/queries.sql."""
import re
import sqlite3
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "ola.db"
SQL_PATH = ROOT / "sql" / "queries.sql"


def load_queries(path: Path = SQL_PATH) -> dict[str, dict]:
    """Return {'Q1': {'title': ..., 'sql': ...}, ...} parsed from the .sql file."""
    text = path.read_text()
    out = {}
    pattern = re.compile(r"-- ((?:Q|X)\d+): ([^\n]*)\n(.*?);", re.S)
    for key, title, sql in pattern.findall(text):
        out[key] = {"title": title.strip(), "sql": sql.strip() + ";"}
    return out


def run_query(sql: str, db_path: Path = DB_PATH) -> pd.DataFrame:
    # Read-only connection: the Streamlit SQL box can never modify the data.
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        return pd.read_sql_query(sql, con)
    finally:
        con.close()
