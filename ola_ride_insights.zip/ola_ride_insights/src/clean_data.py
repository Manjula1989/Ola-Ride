"""Clean the OLA ride dataset and load it into SQLite.

Usage:
    python src/clean_data.py path/to/OLA_DataSet.xlsx

Outputs (in ./data):
    ola_clean.csv   - cleaned, analysis-ready table (also the Power BI source)
    ola.db          - SQLite database with tables `rides` and `vehicle_images`
"""
import sqlite3
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


def clean(xlsx_path: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw = pd.read_excel(xlsx_path, sheet_name="July")
    imgs = pd.read_excel(xlsx_path, sheet_name="Sheet2", header=None, names=["Vehicle_Type", "Image_URL"])
    imgs = imgs.dropna().reset_index(drop=True)

    df = raw.copy()
    # Unnamed/helper columns and the formula-driven image column are not data.
    df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")]
    df = df.drop(columns=["Vehicle Images"], errors="ignore")

    # Standardise text: strip spaces, turn literal 'null' strings into real NaN.
    obj = df.select_dtypes(include=["object", "string"]).columns
    for c in obj:
        if c != "Time":
            df[c] = df[c].astype("string").str.strip().replace({"null": pd.NA, "": pd.NA})

    # Types
    df["Date"] = pd.to_datetime(df["Date"])
    df["Time"] = df["Time"].astype(str).str.slice(0, 8)
    df["Booking_Timestamp"] = pd.to_datetime(
        df["Date"].dt.strftime("%Y-%m-%d") + " " + df["Time"], errors="coerce"
    )
    df["Date"] = df["Date"].dt.normalize()
    for c in ["V_TAT", "C_TAT", "Booking_Value", "Ride_Distance", "Driver_Ratings", "Customer_Rating"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Consistent column naming
    df = df.rename(columns={"Canceled_Rides_by_Customer": "Cancel_Reason_Customer",
                            "Canceled_Rides_by_Driver": "Cancel_Reason_Driver"})

    # Remove exact duplicate bookings (none expected, kept as a safeguard)
    df = df.drop_duplicates(subset="Booking_ID").reset_index(drop=True)

    # Derived features
    df["Hour"] = df["Booking_Timestamp"].dt.hour
    df["Day_Name"] = df["Date"].dt.day_name()
    df["Day_Of_Week"] = df["Date"].dt.dayofweek          # Monday = 0
    df["Is_Weekend"] = df["Day_Of_Week"].isin([5, 6]).astype(int)
    df["Week_Of_Month"] = (df["Date"].dt.day - 1) // 7 + 1
    df["Time_Of_Day"] = pd.cut(
        df["Hour"], bins=[-1, 5, 11, 16, 20, 23],
        labels=["Night", "Morning", "Afternoon", "Evening", "Late Night"],
    ).astype(str)
    df["Is_Success"] = (df["Booking_Status"] == "Success").astype(int)
    df["Is_Incomplete"] = (df["Incomplete_Rides"] == "Yes").fillna(False).astype(int)
    df["Same_Pickup_Drop"] = (df["Pickup_Location"] == df["Drop_Location"]).astype(int)
    df["Fare_Per_Km"] = (df["Booking_Value"] / df["Ride_Distance"]).where(df["Ride_Distance"] > 0).round(2)
    # Revenue only counts when a ride was actually completed; cancelled bookings carry a quoted fare.
    df["Realised_Revenue"] = df["Booking_Value"].where((df["Is_Success"] == 1) & (df["Is_Incomplete"] == 0), 0)
    return df, imgs


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    DATA.mkdir(exist_ok=True)
    df, imgs = clean(sys.argv[1])
    df.to_csv(DATA / "ola_clean.csv", index=False)

    db = DATA / "ola.db"
    if db.exists():
        db.unlink()
    out = df.copy()
    for c in ["Date", "Booking_Timestamp"]:
        out[c] = out[c].dt.strftime("%Y-%m-%d %H:%M:%S" if c == "Booking_Timestamp" else "%Y-%m-%d")
    with sqlite3.connect(db) as con:
        out.to_sql("rides", con, index=False)
        imgs.to_sql("vehicle_images", con, index=False)
        con.execute("CREATE INDEX idx_status ON rides(Booking_Status)")
        con.execute("CREATE INDEX idx_vehicle ON rides(Vehicle_Type)")
        con.execute("CREATE INDEX idx_customer ON rides(Customer_ID)")
    print(f"Clean rows: {len(df):,}  columns: {df.shape[1]}")
    print(df.isna().sum()[lambda s: s > 0])


if __name__ == "__main__":
    main()
